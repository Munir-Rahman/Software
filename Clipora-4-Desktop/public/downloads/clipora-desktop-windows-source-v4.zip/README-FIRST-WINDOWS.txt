CLIPORA DESKTOP 4.0 SOURCE PACKAGE (NOT A COMPILED EXE)

Extract, install Node.js >=22.12 and run SETUP-CLIPORA.cmd, then START-CLIPORA.cmd. Visit http://127.0.0.1:5173. Internet required for setup and online videos.
