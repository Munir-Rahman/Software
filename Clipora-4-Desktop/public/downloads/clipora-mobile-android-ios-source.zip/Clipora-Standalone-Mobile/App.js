import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Image, Keyboard, Linking, Platform, Pressable, ScrollView, StatusBar, StyleSheet, Text, TextInput, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';
import * as Sharing from 'expo-sharing';
import { File } from 'expo-file-system';
import { WebView } from 'react-native-webview';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { mediaButtonScript } from './src/browserScript';
import { normalizeUrl, directInfo, safeLabel } from './src/core.cjs';
import { addToLibrary, cleanupMissingFiles, readLibrary, removeFromLibrary } from './src/localStore';
import { hasExtractor, inspectLink, createDirectTask, extractOnAndroid, cancelNative, watchExtractProgress, getDownloadDirectory } from './src/localEngine';

const C={navy:'#071b28',deep:'#102b36',mint:'#53ddb0',green:'#12a57c',paper:'#fff',bg:'#f3f7f8',text:'#152b35',muted:'#6f8693',edge:'#e1ebee',red:'#c73741'};
const AUDIO=[64,96,128,160,192,256,320];
const P=['YouTube','TikTok','Instagram','Facebook','X / Twitter','Telegram','Coursera','LinkedIn','Other'];
const uid=()=>`${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
const bytes=n=>!n?'—':n>1073741824?`${(n/1073741824).toFixed(2)} GB`:n>1048576?`${(n/1048576).toFixed(1)} MB`:`${Math.round(n/1024)} KB`;
function Copy({children,size=14,weight='500',color=C.text,style,...props}){return <Text {...props} style={[{fontSize:size,color,fontWeight:weight,lineHeight:Math.round(size*1.43)},style]}>{children}</Text>}
function Button({text,onPress,outline=false,small=false,disabled=false,style}){return <Pressable disabled={disabled} onPress={onPress} style={({pressed})=>[S.button,outline&&S.outline,small&&S.small,disabled&&{opacity:.5},pressed&&{opacity:.85},style]}><Copy size={small?12:14} weight="800" color={outline?C.green:C.navy}>{text}</Copy></Pressable>}
function Card({children,style}){return <View style={[S.card,style]}>{children}</View>}
function Chips({values,current,onChange}){return <View style={S.chipRow}>{values.map(v=><Pressable key={String(v)} onPress={()=>onChange(v)} style={[S.chip,current===v&&S.chipActive]}><Copy size={11} color={current===v?'#07664d':C.muted} weight="800">{String(v)}</Copy></Pressable>)}</View>}
function Header({subtitle}){return <LinearGradient colors={[C.navy,C.deep]} style={S.header}><Copy size={29} weight="900" color="white">Clipora <Text style={{color:C.mint}}>Local</Text></Copy><Copy color="#b8d4d9" size={12}>{subtitle}</Copy><View style={S.headerTag}><Copy size={11} weight="800" color={C.mint}>● On your phone  ·  No Clipora server</Copy></View></LinearGradient>}
function filenameFromUri(uri){try{return decodeURIComponent(uri.split('/').pop()||'file')}catch{return 'file'}}

export default function App(){
 const [tab,setTab]=useState('download');
 const [url,setUrl]=useState(''); const [info,setInfo]=useState(null);const [busy,setBusy]=useState(false);const [error,setError]=useState('');
 const [format,setFormat]=useState('mp4');const [quality,setQuality]=useState(720);const [bitrate,setBitrate]=useState(192);
 const [selected,setSelected]=useState({});const [collection,setCollection]=useState('');
 const [jobs,setJobs]=useState([]);const [library,setLibrary]=useState([]);const [filter,setFilter]=useState('All');
 const tasks=useRef(new Map());const jobsRef=useRef([]);const mounted=useRef(true);
 const [browserAddress,setBrowserAddress]=useState('https://example.org');const [browserPage,setBrowserPage]=useState('https://example.org'); const [currentPage,setCurrentPage]=useState('https://example.org');
 const browser=useRef(null); const [browserNav,setBrowserNav]=useState({back:false,forward:false});
 const nativeAvailable=Platform.OS==='android' && hasExtractor();
 const updateJobs=(fn)=>setJobs(old=>{const next=fn(old);jobsRef.current=next;return next;});
 const refresh=useCallback(async()=>setLibrary(await cleanupMissingFiles()),[]);
 useEffect(()=>{mounted.current=true;refresh();const unlisten=watchExtractProgress(e=>{
   if(!mounted.current)return;
   updateJobs(prev=>prev.map(j=>j.id===e.id?{...j,progress:e.progress||0}:j));
 });return ()=>{mounted.current=false;unlisten()};},[refresh]);
 const saveEntry=async entry=>{await addToLibrary(entry);await refresh()};
 const setJob=(id,patch)=>updateJobs(jobs=>jobs.map(j=>j.id===id?{...j,...patch}:j));
 const handleDirect=async(url,title,group='Direct downloads')=>{
   const data=directInfo(url);if(!data)throw Error('This is not a direct media file URL.');
   const id=uid(); const {task}=createDirectTask(data.url,title||data.name,({bytesWritten,totalBytes})=>{
     setJob(id,{progress:totalBytes>0?Math.floor(bytesWritten/totalBytes*100):null,received:bytesWritten,total:totalBytes});
   });
   tasks.current.set(id,task);updateJobs(old=>[{id,title:title||data.name,url,status:'downloading',progress:0,kind:data.kind},...old]);
   try {
     const file=await task.downloadAsync();
     if(!file)throw Error('Download paused; complete it from the current session.');
     const entry={id,uri:file.uri,title:title||data.name,group,kind:data.kind,source:data.url,createdAt:Date.now(),size:file.size||0,status:'complete'};
     await saveEntry(entry);setJob(id,{status:'complete',progress:100});
   }catch(e){setJob(id,{status:String(e.message).toLowerCase().includes('cancel')?'cancelled':'error',message:e.message});}
   finally{tasks.current.delete(id)};
 };
 const handleNative=async(source,title,group='Social videos')=>{
   const id=uid();updateJobs(old=>[{id,title:title||'Social video',url:source,status:'downloading',progress:0,kind:format},...old]);
   try {
     const result=await extractOnAndroid(source,{id,format, height:quality,bitrate,title});
     const file=new File(result.uri);
     const entry={id,uri:result.uri,title:result.name||title||'Downloaded media',group,kind:format==='mp3'?'audio':'video',source,createdAt:Date.now(),size:file.exists?file.size:result.size||0,status:'complete'};
     await saveEntry(entry);setJob(id,{status:'complete',progress:100});
   }catch(e){setJob(id,{status:'error',message:e.message})}
 };
 const analyze=async(v=url)=>{
   setBusy(true);setError('');setInfo(null);Keyboard.dismiss();
   try {const data=await inspectLink(v);setInfo(data);setUrl(v);setSelected(Object.fromEntries((data.entries||[]).map((x,i)=>[i,true])));setCollection(data.mode==='playlist'?data.title:'');
     if(data.mode==='unsupported')setError(data.reason);
     if(data.mode==='direct')setFormat('original');else setFormat('mp4');
   }catch(e){setError(e.message)}finally{setBusy(false)}
 };
 const submit=()=>{
   if(!info)return;
   if(info.mode==='direct'){handleDirect(info.url,info.title,collection||'Direct downloads');setTab('library');return;}
   if(info.mode==='unsupported'){Alert.alert('Extraction unavailable',info.reason);return;}
   if(info.mode==='playlist'){
     const items=info.entries.filter((e,i)=>selected[i]);if(!items.length){Alert.alert('Select videos','Choose at least one playlist item.');return;}
     // sequential queue: avoid dozens of simultaneous massive downloads
     (async()=>{for(const item of items){await handleNative(item.url,item.title,collection||info.title)}})();
     setTab('library');return;
   }
   handleNative(info.url,info.title,collection||'Social videos');setTab('library');
 };
 const paste=async()=>{const t=await Clipboard.getStringAsync();setUrl(t.trim());setInfo(null);setError('')};
 const fromBrowser=link=>{setTab('download');setUrl(link);setInfo(null);analyze(link)};
 const browseMsg=e=>{try{const payload=JSON.parse(e.nativeEvent.data);if(payload.type==='media'&&directInfo(payload.url)){
     Alert.alert('Media available','Save this media directly to your phone?',[
       {text:'Cancel',style:'cancel'},{text:'Download',onPress:()=>{handleDirect(payload.url,filenameFromUri(payload.url),'Browser');setTab('library')}}]);
   }}catch{/* untrusted page messages are ignored */}};
 const browseGo=()=>{try{const next=normalizeUrl(browserAddress);setBrowserPage(next);setCurrentPage(next);Keyboard.dismiss()}catch(e){Alert.alert('URL not allowed',e.message)}};
 const importFiles=async()=>{
   try{const picked=await File.pickFileAsync({multipleFiles:true,mimeTypes:['image/*','video/*','audio/*']});if(picked.canceled)return;
     const dir=getDownloadDirectory();let count=0;
     for(const item of picked.result){if(count>=25)break; const name=safeLabel(item.name||'import');const file=new File(dir,`${uid()}-${name}`);item.copy(file);
       await addToLibrary({id:uid(),uri:file.uri,title:name,group:'Imported',kind:'import',source:'device',createdAt:Date.now(),size:file.size||0,status:'complete'});count++;
     }await refresh();Alert.alert('Imported',`${count} file(s) saved in Clipora.`);
   }catch(e){Alert.alert('Import failed',e.message)}
 };
 const share=async item=>{try{if(await Sharing.isAvailableAsync())await Sharing.shareAsync(item.uri,{dialogTitle:item.title});else Alert.alert('Unavailable','Sharing is not supported here.')}catch(e){Alert.alert('Share failed',e.message)}};
 const remove=async item=>{Alert.alert('Delete file?',`Permanently delete ${item.title}?`,[
   {text:'Cancel',style:'cancel'},{text:'Delete',style:'destructive',onPress:async()=>{try{const f=new File(item.uri);if(f.exists)f.delete();await removeFromLibrary(item.uri);await refresh()}catch(e){Alert.alert('Cannot delete',e.message)}}}
 ])};
 const cancel=id=>{const task=tasks.current.get(id);if(task){task.cancel();setJob(id,{status:'cancelled'});}else if(nativeAvailable){cancelNative(id).then(()=>setJob(id,{status:'cancelled'})).catch(e=>Alert.alert('Cancel failed',e.message));}else Alert.alert('Not available','No active download.');};
 const groups=['All',...new Set(library.map(x=>x.group).filter(Boolean))];
 return <SafeAreaProvider><SafeAreaView edges={['top','bottom']} style={S.safe}><StatusBar barStyle="dark-content"/>
 <View style={S.main}>
 {tab==='download'&&<ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{paddingBottom:28}}>
   <Header subtitle="Save files without a PC or separate server"/>
   <View style={S.content}>
     <Card style={{marginTop:-26}}>
       <Copy size={21} weight="900">Download a video</Copy><Copy size={12} color={C.muted} style={{marginTop:5}}>Paste a link, or choose a file from your device.</Copy>
       <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginTop:15}}>{P.map(p=><View key={p} style={S.platform}><Copy size={11} weight="800" color={C.muted}>{p}</Copy></View>)}</ScrollView>
       <Copy size={12} weight="800" style={{marginTop:17,marginBottom:8}}>Media URL</Copy>
       <View style={S.inputRow}><TextInput style={S.input} placeholder="https://example.com/video.mp4" placeholderTextColor="#93a7af" value={url} onChangeText={v=>{setUrl(v);setInfo(null);setError('')}} keyboardType="url" autoCapitalize="none" autoCorrect={false}/><Button small outline text="Paste" onPress={paste}/></View>
       <Button text={busy?'Inspecting…':'Find my media  →'} disabled={busy} onPress={()=>analyze()} style={{marginTop:12}}/>
       <Button text="Import from phone" outline onPress={importFiles} style={{marginTop:10}}/>
       {error?<View style={S.warning}><Copy color="#97562f" size={12}>{error}</Copy></View>:null}
     </Card>
     {info&&info.mode!=='unsupported'&&<Card style={{marginTop:14}}>
       <Copy color={C.green} weight="900" size={12}>✓ {info.mode==='playlist'?'PLAYLIST FOUND':'MEDIA FOUND'}</Copy>
       <Copy size={17} weight="900" style={{marginTop:10}}>{info.title}</Copy>
       {info.mode==='direct'?<Copy color={C.muted} size={12} style={{marginTop:5}}>Direct {info.kind} · original quality · saved locally</Copy>:<>
         {info.thumbnail?<Image source={{uri:info.thumbnail}} style={S.thumb}/>:null}
         <Copy size={12} color={C.muted} style={{marginTop:5}}>Source: {info.platform||'Public link'}</Copy>
         {info.mode==='playlist'?<><Copy weight="800" size={13} style={{marginTop:14}}>Playlist videos ({info.entries.length})</Copy><View style={S.row}><Button small outline text="All" onPress={()=>setSelected(Object.fromEntries(info.entries.map((e,i)=>[i,true])))}/><Button small outline text="None" onPress={()=>setSelected({})}/></View>
           {info.entries.map((e,i)=><Pressable key={String(i)} style={S.entry} onPress={()=>setSelected(o=>({...o,[i]:!o[i]}))}><Copy color={selected[i]?C.green:C.muted} weight="900">{selected[i]?'☑':'☐'}</Copy><Copy style={{flex:1}} size={12} numberOfLines={2}>{i+1}. {e.title}</Copy></Pressable>)}
         </>:null}
         <Copy weight="800" style={{marginTop:17}} size={12}>Format</Copy><Chips values={['mp4','mp3']} current={format} onChange={setFormat}/>
         {format==='mp4'?<><Copy weight="800" size={12} style={{marginTop:12}}>Maximum video resolution</Copy><Chips values={(info.resolutions?.length?info.resolutions:[360,480,720,1080]).map(x=>`${x}p`)} current={`${quality}p`} onChange={v=>setQuality(Number(v.slice(0,-1)))}/><Copy size={11} color={C.muted}>Not all selected resolutions are available for every video.</Copy></>:
           <><Copy weight="800" size={12} style={{marginTop:12}}>MP3 output bitrate</Copy><Chips values={AUDIO.map(x=>`${x} kbps`)} current={`${bitrate} kbps`} onChange={v=>setBitrate(Number(v.split(' ')[0]))}/><Copy size={11} color={C.muted}>Higher kbps does not increase source audio fidelity.</Copy></>}
       </>}
       <Copy weight="800" size={12} style={{marginTop:15}}>Collection</Copy><TextInput style={[S.input,S.fullInput]} value={collection} onChangeText={setCollection} placeholder="e.g. Course or Playlist" placeholderTextColor="#93a7af"/>
       <Button style={{marginTop:15}} text={info.mode==='playlist'?`Download ${Object.values(selected).filter(Boolean).length} selected`:'Save to my phone  ↓'} onPress={submit}/>
     </Card>}
     <Card style={{marginTop:14,backgroundColor:'#e9f8f3'}}><Copy size={12} weight="900" color="#087852">Device engine</Copy><Copy size={12} color="#476f64" style={{marginTop:6}}>{nativeAvailable?'Android extractor module detected. Supported public social links can be analyzed on-device.':'Direct HTTPS images, audio, videos and documents work on this phone. Social-site extraction needs the Android native build and is not available on iOS in this release.'}</Copy></Card>
     <Copy size={11} color={C.muted} style={{marginTop:15,textAlign:'center'}}>Download only content you own or have permission to save. DRM and login restrictions are not bypassed.</Copy>
   </View>
 </ScrollView>}
 {tab==='browser'&&<View style={{flex:1}}>
   <View style={S.browserControls}><Copy size={21} weight="900">Browse & download</Copy><Copy size={11} color={C.muted}>Buttons on accessible images and HTML5 videos</Copy>
     <View style={[S.inputRow,{marginTop:10}]}><TextInput value={browserAddress} onChangeText={setBrowserAddress} style={S.input} autoCapitalize="none" autoCorrect={false} keyboardType="url" onSubmitEditing={browseGo}/><Button text="Go" small onPress={browseGo}/></View>
     <View style={[S.row,{marginTop:9,justifyContent:'space-between'}]}><View style={S.row}><Button outline small text="←" disabled={!browserNav.back} onPress={()=>browser.current?.goBack()}/><Button outline small text="→" disabled={!browserNav.forward} onPress={()=>browser.current?.goForward()}/><Button outline small text="↻" onPress={()=>browser.current?.reload()}/></View><Button small outline text="Analyze page" onPress={()=>fromBrowser(currentPage)}/></View>
   </View>
   <WebView key={browserPage} ref={browser} source={{uri:browserPage}} javaScriptEnabled={true} injectedJavaScript={mediaButtonScript} onMessage={browseMsg} sharedCookiesEnabled={false} thirdPartyCookiesEnabled={false} incognito={true} startInLoadingState={true} allowsInlineMediaPlayback={true} setSupportMultipleWindows={false}
      originWhitelist={['https://*']} onNavigationStateChange={nav=>{setBrowserNav({back:nav.canGoBack,forward:nav.canGoForward});if(nav.url?.startsWith('https://')){setBrowserAddress(nav.url);setCurrentPage(nav.url)}}}
      onShouldStartLoadWithRequest={req=>{try{normalizeUrl(req.url);return true;}catch{return req.url==='about:blank'}}}
      renderError={()=> <View style={{padding:30}}><Copy>Website unavailable. Some websites block in-app browsers.</Copy></View>}/>
   <View style={{padding:9,backgroundColor:'#e9f8f3'}}><Copy size={10} color={C.muted}>Protected, blob: and encrypted streams are not detected. No browser extension is installed.</Copy></View>
 </View>}
 {tab==='library'&&<ScrollView contentContainerStyle={{paddingBottom:26}}>
    <Header subtitle="Your on-device files and active downloads"/><View style={S.content}><Card style={{marginTop:-24}}><View style={[S.row,{justifyContent:'space-between'}]}><Copy size={20} weight="900">My Library</Copy><Button small outline text="Refresh" onPress={refresh}/></View><Copy color={C.muted} size={12}>Files remain on your phone, not on any Clipora server.</Copy><Button text="Import a status or media file" onPress={importFiles} style={{marginTop:13}}/></Card>
      {jobs.filter(j=>j.status!=='complete').length>0&&<Card style={{marginTop:13}}><Copy weight="900">Active and recent jobs</Copy>{jobs.filter(j=>j.status!=='complete').map(j=><View key={j.id} style={S.item}><Copy weight="800" size={12} numberOfLines={2}>{j.title}</Copy><Copy size={11} color={j.status==='error'?C.red:C.muted}>{j.status}{j.progress!=null?` · ${j.progress}%`:''}{j.message?` · ${j.message}`:''}</Copy>{j.status==='downloading'?<Button small outline text="Cancel download" onPress={()=>cancel(j.id)} style={{marginTop:5}}/>:null}</View>)}</Card>}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginTop:15}}>{groups.map(g=><Pressable key={g} onPress={()=>setFilter(g)} style={[S.chip,filter===g&&S.chipActive,{marginRight:8}]}><Copy size={12} weight="800" color={filter===g?'#096a50':C.muted}>{g}</Copy></Pressable>)}</ScrollView>
      {library.filter(x=>filter==='All'||filter===x.group).map(item=><Card key={item.id||item.uri} style={{marginTop:12}}><View style={S.row}><View style={S.fileIcon}><Copy size={21}>{item.kind==='image'?'▧':item.kind==='audio'?'♫':'▶'}</Copy></View><View style={{flex:1}}><Copy size={13} weight="900" numberOfLines={2}>{item.title}</Copy><Copy color={C.muted} size={11}>{item.group} · {bytes(item.size)}</Copy></View></View><View style={[S.row,{marginTop:11}]}><Button small text="Share / Save externally" onPress={()=>share(item)} style={{flex:1}}/><Button small outline text="Delete" onPress={()=>remove(item)}/></View></Card>)}
      {library.length===0&&<Card style={{marginTop:13}}><Copy color={C.muted}>No files saved yet. Download a direct media link or import files from your phone.</Copy></Card>}
    </View>
 </ScrollView>}
 {tab==='about'&&<ScrollView><Header subtitle="Architecture, capabilities and restrictions"/><View style={S.content}><Card style={{marginTop:-24}}><Copy size={20} weight="900">No server required</Copy><Copy size={13} style={{marginTop:8}}>Downloads happen directly on your Android or iPhone. Saved files live in the app’s document storage and can be shared/exported using the operating system.</Copy>
  <Copy size={14} weight="800" style={{marginTop:14}}>Android native extractor</Copy><Copy size={12} color={C.muted}>Bundled source module uses youtubedl-android and FFmpeg. Requires a custom Android APK, not Expo Go. It may fail when providers change their websites, require login, or use DRM.</Copy>
  <Copy size={14} weight="800" style={{marginTop:14}}>iOS</Copy><Copy size={12} color={C.muted}>Direct file downloads and the media browser are implemented. Social-video/playlist extraction and transcoding are NOT implemented for iOS in this build.</Copy>
  <Copy size={14} weight="800" style={{marginTop:14}}>WhatsApp / Telegram</Copy><Copy size={12} color={C.muted}>Import media you can access using the system Files picker. Private app folders and statuses cannot be read automatically on iOS or newer Android versions.</Copy>
  <Copy size={14} weight="800" style={{marginTop:14}}>Internet</Copy><Copy size={12} color={C.muted}>No separate PC/server is required, but the phone needs internet access to fetch online media. Local saved files remain available without internet.</Copy>
 </Card></View></ScrollView>}
 </View>
 <View style={S.bottom}>{[['download','⬇','Download'],['browser','◎','Browser'],['library','▦','Library'],['about','ⓘ','About']].map(([id,icon,label])=><Pressable key={id} onPress={()=>setTab(id)} style={[S.navTab,tab===id&&S.navSelected]}><Copy size={22} color={tab===id?C.green:C.muted}>{icon}</Copy><Copy size={10} weight="900" color={tab===id?C.green:C.muted}>{label}</Copy></Pressable>)}</View>
 </SafeAreaView></SafeAreaProvider>;
}
const S=StyleSheet.create({safe:{flex:1,backgroundColor:C.bg},main:{flex:1},header:{paddingHorizontal:22,paddingTop:35,paddingBottom:61},headerTag:{alignSelf:'flex-start',marginTop:15,borderWidth:1,borderColor:'#345c60',borderRadius:20,paddingHorizontal:11,paddingVertical:6},content:{paddingHorizontal:17},card:{backgroundColor:C.paper,padding:17,borderRadius:19,borderWidth:1,borderColor:C.edge,shadowColor:C.navy,shadowOpacity:.06,shadowRadius:14,elevation:2},inputRow:{flexDirection:'row',gap:8,alignItems:'center'},input:{borderWidth:1,borderColor:C.edge,borderRadius:11,paddingVertical:12,paddingHorizontal:12,fontSize:12,color:C.text,backgroundColor:'#fbfdfe',flex:1,minWidth:0},fullInput:{flex:0,marginTop:7},button:{minHeight:43,paddingHorizontal:15,paddingVertical:10,backgroundColor:C.mint,borderRadius:11,alignItems:'center',justifyContent:'center'},outline:{backgroundColor:'#f0f9f5',borderWidth:1,borderColor:'#d7ebe3'},small:{minHeight:35,paddingHorizontal:11,paddingVertical:7},platform:{paddingVertical:8,paddingHorizontal:13,borderWidth:1,borderRadius:10,borderColor:C.edge,marginRight:7},chipRow:{flexDirection:'row',flexWrap:'wrap',gap:7,marginTop:9,marginBottom:6},chip:{borderWidth:1,borderColor:C.edge,borderRadius:9,paddingVertical:9,paddingHorizontal:11,backgroundColor:'#f9fbfc'},chipActive:{borderColor:C.mint,backgroundColor:'#e9f9f1'},warning:{padding:12,backgroundColor:'#fff3e5',borderRadius:9,marginTop:13},thumb:{marginTop:13,height:145,borderRadius:10,resizeMode:'cover'},entry:{flexDirection:'row',alignItems:'center',gap:9,paddingVertical:10,borderBottomWidth:1,borderColor:C.edge},row:{flexDirection:'row',alignItems:'center',gap:8},browserControls:{padding:13,backgroundColor:'white',borderBottomColor:C.edge,borderBottomWidth:1},item:{paddingTop:10,marginTop:9,borderTopWidth:1,borderColor:C.edge},fileIcon:{width:45,height:45,backgroundColor:'#e6f9f0',borderRadius:12,justifyContent:'center',alignItems:'center'},bottom:{flexDirection:'row',paddingHorizontal:9,paddingTop:6,paddingBottom:6,backgroundColor:'white',borderTopWidth:1,borderColor:C.edge},navTab:{flex:1,alignItems:'center',justifyContent:'center',minHeight:52,gap:1},navSelected:{backgroundColor:'#edf9f4',borderRadius:10}});
