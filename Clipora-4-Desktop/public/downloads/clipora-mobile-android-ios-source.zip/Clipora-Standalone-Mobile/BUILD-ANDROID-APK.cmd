@echo off
setlocal
cd /d "%~dp0"
echo ==================================================
echo  CLIPORA STANDALONE - ANDROID CUSTOM APK BUILD
 echo  Requires Expo account, Android signing, internet
 echo ==================================================
echo Before continuing, read README.md and GPL obligations.
call npx.cmd eas-cli@latest login
if errorlevel 1 exit /b 1
call npx.cmd eas-cli@latest build --platform android --profile preview
if errorlevel 1 (
  echo Android native build failed. Review full Gradle logs on Expo.
  pause
  exit /b 1
)
echo Expo will provide an APK download link after a successful build.
pause
