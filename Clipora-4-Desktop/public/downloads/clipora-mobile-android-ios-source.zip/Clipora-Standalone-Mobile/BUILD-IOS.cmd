@echo off
setlocal
cd /d "%~dp0"
echo WARNING: iOS supports only direct media downloads; no social extractor.
echo Apple signing and App Store authorization rules apply.
call npx.cmd eas-cli@latest login
if errorlevel 1 exit /b 1
call npx.cmd eas-cli@latest build --platform ios --profile preview
pause
