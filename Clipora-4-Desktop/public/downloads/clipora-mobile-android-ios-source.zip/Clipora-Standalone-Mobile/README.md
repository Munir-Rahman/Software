# Clipora Local — Android and iOS, no separate server

**Status: source implementation and unverified Android native module; not a signed or tested APK/IPA.**

This project replaces the previous Clipora mobile client/server architecture with an **on-device** React Native / Expo SDK 58 app. The phone stores the files and performs direct downloads itself. It does **not** require a computer, a Clipora API server, or any proxy after installation. Fetching online media still requires an internet connection.

## What actually works by design

| Capability | Android | iPhone |
|---|---|---|
| Direct public HTTPS video MP4/WebM/MOV etc. | Implemented | Implemented |
| Direct public HTTPS images, audio files, PDF/ZIP | Implemented | Implemented |
| Save to private app document library, import, share, delete | Implemented | Implemented |
| Built-in web browser with Save buttons on supported HTML5 elements | Implemented | Implemented |
| On-device yt-dlp / FFmpeg extractor for public social-media links | Native Android source included; **requires compile and real testing** | **Not implemented** |
| YouTube playlist discovery and item selection | Android native source included; **unverified** | **Not implemented** |
| Convert source audio to MP3 with chosen bitrate | Android native source included; **unverified** | **Not implemented** |
| Automatically install Chrome extensions | Not needed; browser overlay included | Not possible; browser overlay included |
| Automatically read WhatsApp private status directory | Not allowed/implemented; choose files manually | Not allowed/implemented; choose files manually |
| DRM/paywall/login bypass | No | No |

An app that is genuinely offline cannot fetch internet videos. **No server required** does not mean **no internet required**. The source is split into an Expo JS file downloader used on both platforms plus a native Android `youtubedl-android`/FFmpeg bridge. iOS has no equivalent native extractor in this package. Providers can break extraction at any time.

### Important Android native build requirement

The native extractor uses the documented [`youtubedl-android`](https://github.com/yausername/youtubedl-android) version `0.18.1` (`library`, `ffmpeg`), via a local Kotlin Expo module in `modules/clipora-extractor`. It bundles a Python/yt-dlp/FFmpeg runtime at **build time**. It is *not* downloaded by the user at installation time, does not use the Clipora PC backend, and does not work in ordinary Expo Go. Build a **custom** APK through EAS or local Android Studio. YouTube extraction in recent yt-dlp versions may also require EJS/JavaScript runtime support absent from this Android runtime; do not promise YouTube support before testing.

**Licensing:** `youtubedl-android` is GPL-3.0. If you distribute a compiled app containing it, review GPL-3.0 obligations and compatible licenses for your complete distribution. Do not strip attribution or distribute it as closed-source without legal review.

## Setup on Windows

1. Install Node.js **22.13+**. Extract the ZIP to a drive with space, e.g. `D:\Github\1.Downloader\Clipora-Standalone-Mobile`.
2. Open PowerShell in that folder:

   ```powershell
   npm.cmd install
   npm.cmd test
   npx.cmd expo-doctor
   ```

   Alternatively double-click **SETUP-WINDOWS.cmd**.
3. Sign in to [Expo EAS](https://docs.expo.dev/build/introduction/) and create an Android APK build:

   ```powershell
   npx.cmd eas-cli@latest login
   npx.cmd eas-cli@latest build:configure
   npx.cmd eas-cli@latest build --platform android --profile preview
   ```

   You can also use `BUILD-ANDROID-APK.cmd` after initial EAS configuration. If Gradle fails, review the build logs; we could not compile Kotlin/Gradle here.
4. Download the generated APK from the **EAS build result** on your Android phone, install it (only from the build you control), and open Clipora Local. The phone does **not** need your PC to stay on after installing the APK.
5. Local Android Studio build (requires Android SDK/JDK and device/emulator):

   ```powershell
   npx.cmd expo prebuild --platform android
   npx.cmd expo run:android
   ```

   `npm.cmd run start` requires an installed development client (not Expo Go) when using the native Android extractor.

### Build for iPhone

Apple builds require Apple signing and provisioning and typically EAS/cloud macOS tooling:

```powershell
npx.cmd eas-cli@latest build:configure
npx.cmd eas-cli@latest build --platform ios --profile preview
```

**iPhone features are limited to direct public URLs and the browser/Files library in this release.** This build does not contain native iOS yt-dlp or FFmpeg. Android artifacts cannot be installed on iPhone. Direct downloading of content from third-party sites must comply with applicable permissions. Apple's App Store Review Guideline **5.2.3** specifically restricts downloading third-party audio/video without authorization from the sources; app approval is not guaranteed. See [Apple's App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/).

## Everyday use

- **Download tab:** Paste a public HTTPS direct media URL such as `https://your-cdn.example/media/video.mp4`. The app saves it to local `document/clipora/`. You can import existing WhatsApp or Telegram content via the system file picker (if the phone exposes those files). For Android native extractor-supported URLs, the app inspects source metadata on-device and offers source quality/MP3 options.
- **Browser tab:** Browse normally in the native WebView. A small **↓ Save** overlay is added only to qualifying visible HTML5 video or image elements exposing *direct HTTPS media URLs*. DRM, blob URLs, iframe-restricted content, and encrypted streaming cannot be intercepted by this overlay. No desktop Chrome extension is used.
- **Library tab:** View completed files and download progress, group imported/saved files, export/share to Files/Photos/other apps using the OS share sheet, and delete. The app does not magically place files into WhatsApp's internal status directory.
- **About tab:** Shows which capabilities are available on the current device and platform.

## Technical details

- `App.js` — React Native UI, local download flow, playlist interface, browser and file library.
- `src/localEngine.js` — Expo SDK 58 `File.createDownloadTask` for progress/cancel and Android-native extractor dispatch.
- `src/localStore.js` — AsyncStorage index and files in app `Paths.document`.
- `src/browserScript.js` — JavaScript overlay in `react-native-webview` (permission-based, no DRM bypass).
- `src/core.cjs` — URL validation and file type inference shared by app and Node tests.
- `modules/clipora-extractor` — optional Android Kotlin native module using `youtubedl-android:0.18.1` plus FFmpeg.
- `plugins/withAndroidExtractor.js` — ensures `android:extractNativeLibs` for native runtime.
- `eas.json` — preview Android APK / iOS internal build.

### Risks and what still needs device testing

- We ran **6 pure Node tests** and syntactically parsed the JS/JSX. No Android Gradle compile, iOS Xcode build, or live mobile download was possible in this environment. **Therefore this is not certified production-ready.**
- Android extractor dependency may require adjustments for Expo SDK 58 ABI packaging, EJS, Java runtime, permissions, newer Android OS and provider format changes.
- Files with no extension and HLS/DASH manifests are not direct downloads in this UI. The native extractor, if compiled, may handle some.
- Expo download progress may not reflect an accurate percentage if the server does not send a file length. Background transfer behavior is subject to OS limits.
- Some sites forbid webviews, cross-origin access, or downloading. The UI does not pretend the app can bypass those restrictions.
- For large videos, ensure enough device storage; bitrate is a conversion target, not an improvement over original audio.
- **No automatic WhatsApp-status folder access, no login bypass, no private Telegram inspection, no DRM breaking.**

## Helpful primary documentation

- [Expo FileSystem — DownloadTask, File and Paths](https://docs.expo.dev/versions/v58.0.0/sdk/filesystem/)
- [Expo WebView](https://docs.expo.dev/versions/v58.0.0/sdk/webview/)
- [Expo custom native modules](https://docs.expo.dev/modules/get-started/)
- [youtubedl-android](https://github.com/yausername/youtubedl-android)
- [Apple App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
