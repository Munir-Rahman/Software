@echo off
setlocal
cd /d "%~dp0"
echo ==================================================
echo  CLIPORA STANDALONE MOBILE - INSTALL DEPENDENCIES
 echo  No Clipora server required on your computer
 echo ==================================================
node --version
if errorlevel 1 (
  echo Node.js 22.13 or newer is required. Download from https://nodejs.org/
  pause
  exit /b 1
)
call npm.cmd install
if errorlevel 1 (
  echo npm installation failed.
  pause
  exit /b 1
)
call npm.cmd test
if errorlevel 1 (
  echo Unit tests failed.
  pause
  exit /b 1
)
echo Setup completed. Now run BUILD-ANDROID-APK.cmd.
pause
