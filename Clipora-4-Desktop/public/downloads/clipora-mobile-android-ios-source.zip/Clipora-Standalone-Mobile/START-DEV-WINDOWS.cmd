@echo off
setlocal
cd /d "%~dp0"
echo This app includes an Android custom native module.
echo Expo Go cannot load the Android extractor. Use a development build.
call npx.cmd expo start --dev-client --clear
pause
