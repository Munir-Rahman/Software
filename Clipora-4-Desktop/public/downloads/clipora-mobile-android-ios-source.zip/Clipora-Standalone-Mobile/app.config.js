module.exports = {
  expo: {
    name: 'Clipora Local', slug: 'clipora-local', scheme: 'cliporalocal', version: '2.0.0',
    orientation: 'portrait', userInterfaceStyle: 'light',
    icon: './assets/icon.png',
    splash: { image: './assets/splash.png', resizeMode: 'contain', backgroundColor: '#0b1721' },
    android: { package: 'com.clipora.local', adaptiveIcon: { foregroundImage: './assets/icon.png', backgroundColor: '#0b1721' }, permissions: ['INTERNET'] },
    ios: { bundleIdentifier: 'com.clipora.local', supportsTablet: true, infoPlist: { UIFileSharingEnabled: true, LSSupportsOpeningDocumentsInPlace: true } },
    plugins: ['./plugins/withAndroidExtractor'],
    extra: { mode: 'on-device', serverRequired: false }
  }
};
