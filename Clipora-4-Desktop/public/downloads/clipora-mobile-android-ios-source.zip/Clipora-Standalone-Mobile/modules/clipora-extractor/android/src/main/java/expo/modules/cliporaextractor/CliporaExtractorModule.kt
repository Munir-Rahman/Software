package expo.modules.cliporaextractor

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.ffmpeg.FFmpeg
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import org.json.JSONObject
import java.io.File
import java.net.URI
import java.util.concurrent.atomic.AtomicBoolean

/**
 * On-device yt-dlp + FFmpeg for Android. It does not contact a Clipora server.
 * No cookies, DRM circumvention, or login-token extraction are included.
 * This module has not been compiled on an Android toolchain in this environment.
 */
class CliporaExtractorModule : Module() {
  private val initialized = AtomicBoolean(false)

  private fun context(): Context = appContext.reactContext?.applicationContext
    ?: throw IllegalStateException("Android context unavailable")

  private fun initialize() {
    if (initialized.get()) return
    synchronized(initialized) {
      if (!initialized.get()) {
        YoutubeDL.getInstance().init(context())
        FFmpeg.getInstance().init(context())
        initialized.set(true)
      }
    }
  }

  private fun validate(url: String): String {
    if (url.length > 4096) throw IllegalArgumentException("URL too long")
    val uri = URI(url)
    if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null) throw IllegalArgumentException("HTTPS required")
    val host = uri.host.lowercase()
    if (host == "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.matches(Regex("[0-9.]+"))) throw IllegalArgumentException("Local host unsupported")
    return url
  }

  override fun definition() = ModuleDefinition {
    Name("CliporaExtractor")
    Events("onExtractProgress")

    AsyncFunction("inspect") { rawUrl: String ->
      initialize()
      val url = validate(rawUrl)
      val request = YoutubeDLRequest(url)
      request.addOption("--dump-single-json")
      request.addOption("--flat-playlist")
      request.addOption("--playlist-end", "60")
      request.addOption("--skip-download")
      request.addOption("--no-warnings")
      request.addOption("--no-config")
      val out = YoutubeDL.getInstance().execute(request).out
      val json = JSONObject(out.trim())
      val entries = json.optJSONArray("entries")
      val result = mutableMapOf<String, Any>(
        "title" to json.optString("title", "Media"),
        "platform" to json.optString("extractor_key", "Media"),
        "thumbnail" to json.optString("thumbnail", "")
      )
      if (entries != null) {
        val items = mutableListOf<Map<String,String>>()
        for (i in 0 until entries.length()) {
          val item = entries.optJSONObject(i) ?: continue
          val id = item.optString("id")
          var page = item.optString("webpage_url")
          if (!page.startsWith("https://")) {
            if (json.optString("extractor_key").contains("Youtube", ignoreCase = true) && id.isNotBlank()) page = "https://www.youtube.com/watch?v=$id"
            else page = item.optString("url")
          }
          if (!page.startsWith("https://")) continue
          items.add(mapOf("title" to item.optString("title", "Video ${i+1}"), "url" to page))
        }
        if (items.isNotEmpty()) result["entries"] = items
      } else {
        val formats = json.optJSONArray("formats")
        val heights = mutableSetOf<Int>()
        if (formats != null) for (i in 0 until formats.length()) {
          val h = formats.optJSONObject(i)?.optInt("height", 0) ?: 0
          if (h in 144..8640) heights.add(h)
        }
        result["resolutions"] = heights.sortedDescending()
      }
      result
    }

    AsyncFunction("download") { rawUrl: String, options: Map<String, Any> ->
      initialize()
      val url = validate(rawUrl)
      val rawId = options["id"]?.toString() ?: System.currentTimeMillis().toString()
      val id = rawId.replace(Regex("[^a-zA-Z0-9_-]"), "").take(70).ifEmpty { "download" }
      val format = if (options["format"] == "mp3") "mp3" else "mp4"
      val height = (options["height"] as? Number)?.toInt()?.coerceIn(144,4320) ?: 720
      val bitrate = (options["bitrate"] as? Number)?.toInt()?.coerceIn(64,320) ?: 192
      // Always choose a private, app-owned path; never trust a JS-supplied filesystem path.
      val folder = File(context().filesDir, "clipora")
      folder.mkdirs()
      val request = YoutubeDLRequest(url)
      request.addOption("--no-config")
      request.addOption("--no-playlist")
      request.addOption("--no-warnings")
      request.addOption("--restrict-filenames")
      request.addOption("--no-write-thumbnail")
      request.addOption("-o", File(folder, "clipora-$id.%(ext)s").absolutePath)
      if (format == "mp3") {
        request.addOption("-f", "bestaudio/best")
        request.addOption("-x")
        request.addOption("--audio-format", "mp3")
        request.addOption("--audio-quality", "${bitrate}K")
      } else {
        request.addOption("-f", "bv*[height<=$height]+ba/b[height<=$height]/best")
        request.addOption("--merge-output-format", "mp4")
        request.addOption("--recode-video", "mp4")
      }
      YoutubeDL.getInstance().execute(request, { progress, eta ->
        sendEvent("onExtractProgress", mapOf("id" to id, "progress" to progress.toDouble(), "eta" to eta))
      }, id)
      val result = folder.listFiles()?.firstOrNull { it.isFile && it.name.startsWith("clipora-$id.") && !it.name.endsWith(".part") }
        ?: throw IllegalStateException("Download process completed but output file was not found")
      mapOf("path" to result.absolutePath, "name" to result.name, "size" to result.length())
    }

    AsyncFunction("cancel") { id: String ->
      YoutubeDL.getInstance().destroyProcessById(id)
      true
    }
  }
}
