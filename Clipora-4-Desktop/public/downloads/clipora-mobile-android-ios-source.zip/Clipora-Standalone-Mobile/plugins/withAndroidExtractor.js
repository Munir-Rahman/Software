const { withAndroidManifest } = require('@expo/config-plugins');
module.exports = config => withAndroidManifest(config, config => {
  const application = config.modResults.manifest.application?.[0];
  if (application) {
    // Required by youtubedl-android for bundled native Python/FFmpeg .so files.
    application.$['android:extractNativeLibs'] = 'true';
  }
  return config;
});
