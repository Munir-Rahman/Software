// Native WebView injects this on each TOP-LEVEL navigation. This is the built-in
// media button replacement; it does not install a browser extension or bypass DRM.
export const mediaButtonScript = String.raw`
(function () {
  if (window.__cliporaMediaOverlay) return true;
  window.__cliporaMediaOverlay = true;
  const root = document.createElement('div');
  root.id = '__clipora_overlay';
  Object.assign(root.style, { position: 'absolute', left: '0', top: '0', width: '0', height: '0', zIndex: '2147483646', pointerEvents: 'none' });
  const buttons = new Map();
  function mediaLink(el) {
    const candidate = el.tagName === 'VIDEO' ? (el.currentSrc || el.src || el.querySelector('source')?.src) : el.currentSrc || el.src;
    if (!candidate) return null;
    try {
      const u = new URL(candidate, document.baseURI);
      // Only direct public media files, not blob:, data:, HLS manifests, or protected media.
      if (u.protocol !== 'https:' || !/\.(mp4|webm|m4v|mov|mp3|m4a|png|jpg|jpeg|gif|webp)$/i.test(u.pathname)) return null;
      return u.href;
    } catch { return null; }
  }
  function update() {
    if (!document.body || !window.ReactNativeWebView) return;
    if (!root.isConnected) document.body.appendChild(root);
    const elements = [...document.querySelectorAll('video, img')].slice(0, 120);
    const seen = new Set();
    for (const el of elements) {
      const link = mediaLink(el);
      const r = el.getBoundingClientRect();
      if (!link || r.width < 140 || r.height < 90 || !el.isConnected) continue;
      seen.add(el);
      let button = buttons.get(el);
      if (!button) {
        button = document.createElement('button');
        button.textContent = '↓ Save';
        button.type = 'button';
        Object.assign(button.style, {
          position: 'absolute', padding: '8px 12px', borderRadius: '30px',
          border: '1px solid #82f0bf', background: '#0b1721', color: '#8cf0c2',
          boxShadow: '0 4px 12px #0008', font: '600 13px system-ui', pointerEvents: 'auto', cursor: 'pointer'
        });
        button.addEventListener('click', function (event) {
          event.preventDefault(); event.stopPropagation();
          const url = mediaLink(el);
          if (url) window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'media', url }));
        });
        buttons.set(el, button);
        root.appendChild(button);
      }
      button.style.left = Math.round(r.right + scrollX - 82) + 'px';
      button.style.top = Math.round(r.top + scrollY + 8) + 'px';
    }
    for (const [el, button] of buttons) {
      if (!seen.has(el)) { button.remove(); buttons.delete(el); }
    }
  }
  let scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { scheduled = false; update(); });
  }
  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'poster'] });
  window.addEventListener('scroll', schedule, true);
  window.addEventListener('resize', schedule);
  document.addEventListener('loadeddata', schedule, true);
  setInterval(schedule, 4000);
  schedule();
})();
true;
`;
