// Pure, testable guards: no backend, no private-network proxy or remote content scraping.
const EXTENSIONS = Object.freeze({
  mp4: 'video', webm: 'video', mov: 'video', m4v: 'video', m4a: 'audio', mp3: 'audio',
  wav: 'audio', ogg: 'audio', jpg: 'image', jpeg: 'image', png: 'image', gif: 'image', webp: 'image',
  pdf: 'document', zip: 'document'
});
function normalizeUrl(value) {
  const text = String(value || '').trim();
  if (text.length > 4096 || !text) throw Error('Paste a supported HTTPS media link.');
  let u;
  try { u = new URL(text); } catch { throw Error('Invalid URL. Include https://'); }
  if (u.protocol !== 'https:' || !u.hostname || u.username || u.password) throw Error('Only HTTPS media links are accepted.');
  if (u.hostname === 'localhost' || /\.localhost$/.test(u.hostname) || /\.local$/.test(u.hostname) || /^\d+\.\d+\.\d+\.\d+$/.test(u.hostname) || /(^|:)\[[^\]]+\]/.test(u.host)) throw Error('Local or numeric hosts are unsupported.');
  return u.toString();
}
function directInfo(value) {
  const u = new URL(normalizeUrl(value));
  const extension = (u.pathname.match(/\.([a-z0-9]{2,5})$/i) || [])[1]?.toLowerCase();
  if (!extension || !EXTENSIONS[extension]) return null;
  const name = decodeURIComponent(u.pathname.split('/').pop() || 'download').slice(0, 120);
  return { url: u.toString(), extension, kind: EXTENSIONS[extension], name };
}
function safeLabel(label) { return String(label || 'media').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').slice(0, 90).trim() || 'media'; }
function isTrustedNativeUrl(value) { try { return Boolean(normalizeUrl(value)); } catch { return false; } }
function qualityList(metadata) {
  const h = (metadata?.resolutions || []).filter(n => Number.isInteger(n) && n >= 144 && n <= 8640);
  return [...new Set(h)].sort((a,b)=>b-a);
}
module.exports = { normalizeUrl, directInfo, safeLabel, isTrustedNativeUrl, qualityList, EXTENSIONS };
