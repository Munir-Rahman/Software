import { File, Directory, Paths } from 'expo-file-system';
import { requireOptionalNativeModule, EventEmitter } from 'expo-modules-core';
import { directInfo, safeLabel, normalizeUrl } from './core.cjs';

// Android optional yt-dlp engine is bundled via local Kotlin module in custom APKs.
// No proxy server. On iOS/Expo Go, this module is absent by design.
const AndroidExtractor = requireOptionalNativeModule('CliporaExtractor');
export function hasExtractor() { return Boolean(AndroidExtractor); }
export function watchExtractProgress(handler) {
  if (!AndroidExtractor) return () => {};
  const sub=new EventEmitter(AndroidExtractor).addListener('onExtractProgress',handler);
  return ()=>sub.remove();
}
export async function inspectLink(link) {
  const url=normalizeUrl(link); const direct=directInfo(url);
  if (direct) return { mode:'direct', ...direct, title:direct.name };
  if (!AndroidExtractor) return { mode:'unsupported', url, reason:'This is a webpage, not a direct media file. On Android, a custom build with the bundled yt-dlp module can attempt extraction. On iPhone, only direct files are supported in this build.' };
  const result=await AndroidExtractor.inspect(url);
  if (!result || !result.title) throw Error('The source did not return usable media metadata.');
  return { ...result, url, mode:result.entries?.length?'playlist':'extractor' };
}
export function getDownloadDirectory() {
  const dir=new Directory(Paths.document, 'clipora');
  if(!dir.exists) dir.create({intermediates:true,idempotent:true});
  return dir;
}
export function createDirectTask(url, name, onProgress) {
  const info=directInfo(url);
  if(!info) throw Error('Not a directly downloadable file.');
  const dir=getDownloadDirectory();
  const file=new File(dir, `${Date.now()}-${Math.random().toString(36).slice(2,9)}-${safeLabel(name || info.name)}`);
  const task=File.createDownloadTask(info.url,file,{onProgress});
  return { task, file, info };
}
export async function extractOnAndroid(url, options={}) {
  if(!AndroidExtractor) throw Error('Native extractor not installed. Build the Android app with EAS or expo run:android, not Expo Go.');
  const safe=normalizeUrl(url);
  const dir=getDownloadDirectory();
  const info=await AndroidExtractor.download(safe,{
    directory: dir.uri.replace(/^file:\/\//,''),
    id: options.id || '',
    format: options.format === 'mp3' ? 'mp3' : 'mp4',
    height: Number(options.height) || 720,
    bitrate: Number(options.bitrate) || 192
  });
  if(!info?.path) throw Error('Native extractor did not report an output file.');
  return { uri:`file://${info.path.replace(/^file:\/\//,'')}`, name:info.name || safeLabel(options.title), size:info.size || 0 };
}

export async function cancelNative(id) {
  if (!AndroidExtractor) return false;
  return await AndroidExtractor.cancel(id);
}
