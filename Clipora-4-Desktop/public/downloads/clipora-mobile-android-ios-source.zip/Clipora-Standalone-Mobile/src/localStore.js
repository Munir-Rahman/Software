import AsyncStorage from '@react-native-async-storage/async-storage';
import { File } from 'expo-file-system';
const KEY='clipora.standalone.library.v2';
export async function readLibrary() {
  try {
    const parsed=JSON.parse(await AsyncStorage.getItem(KEY));
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(x=>typeof x?.uri==='string' && x?.status==='complete').slice(0,500);
  } catch { return []; }
}
export async function addToLibrary(entry) {
  const old=await readLibrary();
  const next=[entry,...old.filter(e=>e.uri!==entry.uri)].slice(0,500);
  await AsyncStorage.setItem(KEY,JSON.stringify(next));
  return next;
}
export async function removeFromLibrary(uri) {
  const next=(await readLibrary()).filter(x=>x.uri!==uri);
  await AsyncStorage.setItem(KEY,JSON.stringify(next));
  return next;
}
export async function cleanupMissingFiles() {
  const old=await readLibrary();
  const next=old.filter(x=>{try{return new File(x.uri).exists;}catch{return false;}});
  if(next.length!==old.length) await AsyncStorage.setItem(KEY,JSON.stringify(next));
  return next;
}
