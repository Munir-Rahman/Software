const {test}=require('node:test');
const assert=require('node:assert/strict');
const {normalizeUrl,directInfo,safeLabel,qualityList}=require('../src/core.cjs');
test('https only, rejects javascript/data/http',()=>{for(const bad of ['javascript:alert(1)','http://example.com/a.mp4','data:x','ftp://example.com/a.mp4'])assert.throws(()=>normalizeUrl(bad));});
test('rejects numeric and local addresses',()=>{for(const u of ['https://127.0.0.1/f.mp4','https://localhost/file.jpg','https://192.168.0.4/a.mp4'])assert.throws(()=>normalizeUrl(u));});
test('recognizes image/audio/video/document',()=>{assert.equal(directInfo('https://cdn.example.org/a.mp4').kind,'video');assert.equal(directInfo('https://cdn.example.org/a.jpg?x=1').kind,'image');assert.equal(directInfo('https://cdn.example.org/a.mp3').kind,'audio');assert.equal(directInfo('https://cdn.example.org/a.pdf').kind,'document');});
test('webpages not mislabeled as direct download',()=>{assert.equal(directInfo('https://youtube.com/watch?v=foo'),null);});
test('preserves quality values without claiming unsupported resolutions',()=>{assert.deepEqual(qualityList({resolutions:[1080,720,1080,360,1]}),[1080,720,360]);});
test('sanitizes unsafe file names',()=>{assert.equal(safeLabel('x:a/b?c'), 'x_a_b_c');});
